module.exports = {
    "lintOnSave": false,
    "transpileDependencies": [
        "vuetify"
    ],
    publicPath: '/mind',
}