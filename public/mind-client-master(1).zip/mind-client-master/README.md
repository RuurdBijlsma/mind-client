# mind-client

Requirements:
* NodeJS
* NPM

Both will be installed with this installer: https://nodejs.org/en/download/

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```
